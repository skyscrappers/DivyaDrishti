import imaplib
import email
from email.header import decode_header
import re
import json
from tqdm import tqdm
from groq import Groq
import os

def clean_text(text):
    text = re.sub(r'[^\w\s]', '', text)
    text = text.strip()
    return text.lower()

def reterive_mails(subject_filter=None):
    imap_server = "imap.gmail.com"
    email_user = "utkarsh21570@iiitd.ac.in"
    email_pass = "jcpk ewix oryf rzpe"

    mail = imaplib.IMAP4_SSL(imap_server)
    mail.login(email_user, email_pass)
    mail.select("inbox")

    status, messages = mail.search(None, 'ALL')

    email_ids = messages[0].split()[-1:]  
    result = {}
    count = 1

    for email_id in tqdm(email_ids, desc="Fetching emails"):
        res, msg = mail.fetch(email_id, "(RFC822)")
        for response_part in msg:
            if isinstance(response_part, tuple):
                msg = email.message_from_bytes(response_part[1])
                subject, encoding = decode_header(msg["Subject"])[0]
                if isinstance(subject, bytes):
                    subject = subject.decode(encoding if encoding else "utf-8")
                from_ = msg.get("From")

                if msg.is_multipart():
                    body = ""
                    for part in msg.walk():
                        content_type = part.get_content_type()
                        if content_type == "text/plain" or content_type == "text/html":
                            body = part.get_payload(decode=True).decode()
                            body = clean_text(body)
                            break
                else:
                    body = msg.get_payload(decode=True).decode()
                    body = clean_text(body)

                result[count] = {
                    "from": clean_text(from_),
                    "subject": clean_text(subject),
                    "body": body
                }

                count += 1

    mail.logout()

    with open("emails.json", "w") as file:
        json.dump(result, file, indent=4)

def llama_process_emails():
    with open("emails.json", "r") as file:
        emails = json.load(file)
    
    llama_input = "Here are the latest emails:\n"
    for key, email_data in emails.items():
        llama_input += f"Email {key}:\n"
        llama_input += f"From: {email_data['from']}\n"
        llama_input += f"Subject: {email_data['subject']}\n"
        llama_input += f"Body: {email_data['body']}\n\n"
    
    os.environ["GROQ_API_KEY"] = ""
    client = Groq(api_key=os.getenv('GROQ_API_KEY'))
    MODEL = "llama-3.1-8b-instant"
    messages = [
        {
            "role": "system",
            "content": "You are supposed to summarize the following emails in a structured and professional way. Start off the summary with who is the sender, their mail address and the subject of the email. your output is going to be read out using TTS so make sure it has no special characters in it and just text. No formatting is required since there is no reader for your output just listener hence no symbol or special characters, use no enters (backslash n) in your output. Mail should be of original length and not shortened at all"
        },
        {
            "role": "user",
            "content": llama_input,
        }
    ]
    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        max_tokens=8000
    )
    
    response_message_content = response.choices[0].message.content
    return response_message_content

def read_emails():
    reterive_mails()
    llama_output = llama_process_emails()
    return llama_output
