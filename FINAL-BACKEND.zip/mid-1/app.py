import os
import json
from groq import Groq
from fastapi import FastAPI
from pydantic import BaseModel
import read_emails
import general_chat
import send_mail
import time
import internet_search
import query_erp
import warnings
import pandas as pd
from PIL import Image
import torch
from imagebind import data
from imagebind.models import imagebind_model
from imagebind.models.imagebind_model import ModalityType
from getpass import getpass
import kdbai_client as kdbai
from together import Together
import cloudinary
import cloudinary.uploader
from cloudinary.utils import cloudinary_url
import ssl
import python_tool




warnings.filterwarnings('ignore')

device = "cuda" if torch.cuda.is_available() else "cpu"

model = imagebind_model.imagebind_huge(pretrained=True)
model.eval()
model.to(device)

print("")

KDBAI_ENDPOINT = 'https://cloud.kdb.ai/instance/ad32inc8wq'
KDBAI_API_KEY = '279b7559d8-N9/aRbxPClfn85K0PQuYH2K0846HId66M5WlOQkkorD5zCC6amlffy6rPgBURPV2rAZG1URwfnPBXZix'


session = kdbai.Session(api_key=KDBAI_API_KEY, endpoint=KDBAI_ENDPOINT)
db = session.database('default')
table = db.table('LLM')

cloudinary.config(
    cloud_name="dodwnkmga",
    api_key="749337223665148",
    api_secret="IbzSJJ0vNMpJGKPABfQ7m0PCn_E",
    secure=True
)

'''-----------------------------------------------------------------------------------------------------------------'''








def visual_question_answering(query):
    print("VQA tool called!")
    TOGETHER_API_KEY = '581f09912b905cd058e92cd71321e5385267b1b3c41396cf8d5057f4ee599bb2'
    client = Together(api_key=TOGETHER_API_KEY)

    def VQA(image, query):
        def getEmbeddingVector(inputs):
            with torch.no_grad():
                embedding = model(inputs)
            for key, value in embedding.items():
                vec = value.reshape(-1)
                vec = vec.cpu().numpy()
                return(vec)
        def queryToEmbedding(dataIn):
            data_path = [dataIn]
            inputs = {
                ModalityType.VISION: data.load_and_transform_vision_data(data_path, device)
            }
            vec = getEmbeddingVector(inputs)
            return(vec)
        image.save("Query.jpg")
        query_vector = [queryToEmbedding("Query.jpg").tolist()]
        results = table.search({'vectorIndex': query_vector}, n=1)
        confidence_score = results[0].values[0][0]
        print(confidence_score)
        if confidence_score >= 0.6:
        
        # use rag
            context = results[0].values[0][3]
            prompt = f"You will be asked a question and you have to give a precise answer based on the context provided. If you don't know the answer, respond with 'unanswerable.'\nContext:{context}\nQuestion: {query}"
        else:
            # don't use rag
            prompt = f"You will be asked a question and you have to give a precise answer. If you don't know the answer, respond with 'unanswerable.'\nQuestion: {query}"
        upload_result = cloudinary.uploader.upload("Query.jpg")
        imageUrl = upload_result["secure_url"]

        print("Prompt: ", prompt)
        output = client.chat.completions.create(
                model="meta-llama/Llama-3.2-11B-Vision-Instruct-Turbo",
                messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": imageUrl}},
                    ],
                }
                ],
                max_tokens=512,
                temperature=0.1,
                top_p=0.7,
                top_k=5,
                repetition_penalty=1,
                stop=["<|eot_id|>","<|eom_id|>"],
                stream=False
        )
        os.remove("Query.jpg")
        return(output.choices[0].message.content)
    
    

    image = Image.open('/home/utkarsh/Desktop/Sem-7/LLM/mid-1/Images/img1.jpeg')
    result = VQA(image, query)
    return result 


print("model loaded successfully!")


os.environ["GROQ_API_KEY"] = "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"
client = Groq(api_key=os.getenv('GROQ_API_KEY'))

MODEL = "llama-3.1-70b-versatile"
MAX_RETRIES = 15
RETRY_DELAY = 0


# CHAT HISTORY LOGIC 
chat_history_file = "chat_history.txt"
if not os.path.exists(chat_history_file):
    with open(chat_history_file, "w") as file:
        file.write("")
with open(chat_history_file, "r") as file:
    history_lines = file.readlines()    
last_50_messages = history_lines[-50:] if len(history_lines) > 50 else history_lines
context = "".join(last_50_messages)



# # # ------------------------------ FASTAPI ------------------------------


app = FastAPI()

# AGENT LOGIC 
class ChatRequest(BaseModel):
    user_prompt: str

def attempt_run_conversation(user_prompt, retries=0):
    messages = [
        {
            "role": "system",
            "content": "You are a function-calling LLM that chooses appropriate tools based on the user's request."
        },
        {
            "role": "user",
            "content": user_prompt,
        }
    ]
    
    tools = [
        {
            "type": "function",
            "function": {
                "name": "read_emails",
                "description": "Read the user's emails",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "student_erp_portal",
                "description": "This agent contains list of courses of the student, grades and CGPA",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "general_chat",
                "description": "Respond to general user queries",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "visual_question_answering",
                "description": "Answer questions related to an image input",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "send_email",
                "description": "Send an email to some email ID",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "python_tool",
                "description": "This is a python tool which can be used for calculation or just generally let's you execute python functions. It can also be used to excute system related commands or answer system related queries of my device",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "internet_search",
                "description": "Search some information from the internet",
            }
        }
    ]
    
    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            max_tokens=4096
        )
        
        response_message = response.choices[0].message
        
        if hasattr(response_message, 'tool_calls') and response_message.tool_calls:
            tool_calls = response_message.tool_calls
            for tool_call in tool_calls:
                tool_name = tool_call.function.name
                print(f"Tool called: {tool_name}")
                if tool_name == "read_emails":
                    return read_emails.read_emails()
                elif tool_name == "general_chat":
                    return general_chat.general_chat(user_prompt)
                elif tool_name == "visual_question_answering":
                    return visual_question_answering(user_prompt)
                elif tool_name == "send_email":
                    return send_mail.send_mail(user_prompt)
                elif tool_name == "internet_search":
                    return internet_search.internet_search(user_prompt)
                elif tool_name == "student_erp_portal":
                    return query_erp.query_student_erp_portal(user_prompt)
                elif tool_name == "python_tool":
                    return python_tool.python_tool(user_prompt)
                

        else:
            raise ValueError("No tools called.")

    except (ValueError, Exception) as e:
        print(f"Error: {e}, retrying in {RETRY_DELAY} seconds...")
        if retries < MAX_RETRIES:
            time.sleep(RETRY_DELAY)
            return attempt_run_conversation(user_prompt, retries + 1)
        else:
            return general_chat.general_chat(user_prompt)
        
def check_safe_text(query):
    api_key = "cd3858f3a2ddb7d61dc261ea5d67eba255fc9011b24ab4594c14ce78282172ac"
    client = Together(api_key = api_key)
    response = client.chat.completions.create(
        model="meta-llama/LlamaGuard-2-8b",
        messages=[{"role": "user", "content": query}],
    )
    print("Safety Check Output from LlamaGuard: ", response.choices[0].message.content)
    ans =  ((response.choices[0].message.content).split("\n")) 
    crime_categories = {
    "S1": "Violent Crimes",
    "S2": "Non-Violent Crimes",
    "S3": "Sex-Related Crimes",
    "S4": "Child Sexual Exploitation",
    "S5": "Defamation",
    "S6": "Specialized Advice",
    "S7": "Privacy",
    "S8": "Intellectual Property",
    "S9": "Indiscriminate Weapons",
    "S10": "Hate",
    "S11": "Suicide & Self-Harm",
    "S12": "Sexual Content",
    "S13": "Elections",
    "S14": "Code Interpreter Abuse"
}

    if len(ans) == 2: 
        print("Violation type: " , crime_categories[ans[1]])
    return ans[0]


@app.post("/run_conversation")
def run_conversation(request: ChatRequest):
    user_prompt = request.user_prompt
    try:
        if check_safe_text(user_prompt) == "unsafe": 
            return "Sorry there is a potential security violation in your request. Please try a different prompt."
            
        result = attempt_run_conversation(user_prompt)

        if check_safe_text(result) == "safe": 
            result = result
        else: 
            result = "Sorry, I can't provide that information due to potential safety violation."
        return result
    except Exception as e:
        return "Sorry I am unable answer that."

# -------------------------------------------------------------------------------------------



# from fastapi import FastAPI, File, UploadFile
# import shutil
# from speech_recognition import Recognizer, AudioFile

# app = FastAPI()

# ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
# ssl_context.load_cert_chain('cert.pem', keyfile='key.pem')

# def audio_to_text(uploaded_audio: UploadFile) -> str:
#     audio_path = "temp_audio_input.wav"
#     with open(audio_path, "wb") as buffer:
#         shutil.copyfileobj(uploaded_audio.file, buffer)
#     recognizer = Recognizer()
#     with AudioFile(audio_path) as source:
#         audio = recognizer.record(source)
#     transcription = recognizer.recognize_google(audio)
#     return transcription

# def attempt_run_conversation(transcribed_text: str, image_path=None, retries=0):
#     messages = [
#         {
#             "role": "system",
#             "content": "You are a function-calling LLM that chooses appropriate tools based on the user's request."
#         },
#         {
#             "role": "user",
#             "content": transcribed_text,
#         }
#     ]
#     tools = [
#         {
#             "type": "function",
#             "function": {
#                 "name": "read_emails",
#                 "description": "Read the user's emails",
#             }
#         },
#         {
#             "type": "function",
#             "function": {
#                 "name": "student_erp_portal",
#                 "description": "This agent contains list of courses of the student, grades and CGPA",
#             }
#         },
#         {
#             "type": "function",
#             "function": {
#                 "name": "general_chat",
#                 "description": "Respond to general user queries",
#             }
#         },
#         {
#             "type": "function",
#             "function": {
#                 "name": "visual_question_answering",
#                 "description": "Answer questions related to an image input",
#             }
#         },
#         {
#             "type": "function",
#             "function": {
#                 "name": "send_email",
#                 "description": "Send an email to some email ID",
#             }
#         },
#         # {
#         #     "type": "function",
#         #     "function": {
#         #         "name": "internet_search",
#         #         "description": "Search some information from the internet",
#         #     }
#         # },
#         {
#             "type": "function",
#             "function": {
#                 "name": "python_tool",
#                 "description": "This is a python tool which can be used for calculation or just generally let's you execute python functions. It can also be used to excute system related commands or answer system related queries of my device",
#             }
#         }
#     ]
#     try:
#         response = client.chat.completions.create(
#             model=MODEL,
#             messages=messages,
#             tools=tools,
#             tool_choice="auto",
#             max_tokens=4096
#         )
#         response_message = response.choices[0].message
#         if hasattr(response_message, 'tool_calls') and response_message.tool_calls:
#             tool_calls = response_message.tool_calls
#             for tool_call in tool_calls:
#                 tool_name = tool_call.function.name
#                 print(f"Tool called: {tool_name}")
#                 if tool_name == "read_emails":
#                     return read_emails.read_emails()
#                 elif tool_name == "general_chat":
#                     return general_chat.general_chat(transcribed_text)
#                 elif tool_name == "visual_question_answering":
#                     return visual_question_answering(transcribed_text)
#                 elif tool_name == "send_email":
#                     return send_mail.send_mail(transcribed_text)
#                 # elif tool_name == "internet_search":
#                 #     return internet_search.internet_search(transcribed_text)
#                 elif tool_name == "student_erp_portal":
#                     return query_erp.query_student_erp_portal(transcribed_text)
#                 elif tool_name == "python_tool": 
#                     return python_tool.python_tool(transcribed_text)
#         else:
#             raise ValueError("No tools called.")
#     except (ValueError, Exception) as e:
#         print(f"Error: {e}, retrying in {RETRY_DELAY} seconds...")
#         if retries < MAX_RETRIES:
#             time.sleep(RETRY_DELAY)
#             return attempt_run_conversation(transcribed_text, image_path, retries + 1)
#         else:
#             return general_chat.general_chat(transcribed_text)

# def check_safe_text(query):
#     api_key = "cd3858f3a2ddb7d61dc261ea5d67eba255fc9011b24ab4594c14ce78282172ac"
#     client = Together(api_key=api_key)
#     response = client.chat.completions.create(
#         model="meta-llama/LlamaGuard-2-8b",
#         messages=[{"role": "user", "content": query}],
#     )
#     print("Safety Check Output from LlamaGuard: ", response.choices[0].message.content)
#     ans = (response.choices[0].message.content).split("\n")
#     crime_categories = {
#         "S1": "Violent Crimes",
#         "S2": "Non-Violent Crimes",
#         "S3": "Sex-Related Crimes",
#         "S4": "Child Sexual Exploitation",
#         "S5": "Defamation",
#         "S6": "Specialized Advice",
#         "S7": "Privacy",
#         "S8": "Intellectual Property",
#         "S9": "Indiscriminate Weapons",
#         "S10": "Hate",
#         "S11": "Suicide & Self-Harm",
#         "S12": "Sexual Content",
#         "S13": "Elections",
#         "S14": "Code Interpreter Abuse"
#     }
#     if len(ans) == 2:
#         print("Violation type: ", crime_categories.get(ans[1], "Unknown"))
#     return ans[0]

# @app.post("/run_conversation")
# async def run_conversation(
#     audio: UploadFile = File(...),
#     image: UploadFile = None
# ):
#     if not audio:
#         return {"error": "Audio input is required."}
#     try:
#         transcribed_text = audio_to_text(audio)
#         print(f"Transcribed Text: {transcribed_text}")
#     except Exception as e:
#         return {"error": f"Failed to process audio: {str(e)}"}
    
#     image_path = None
#     if image:
#         try:
#             image_data = Image.open(image.file)
#             if image_data.mode == "RGBA":
#                 image_data = image_data.convert("RGB")
#             image_path = "Images/img1.jpeg"
#             image_data.save(image_path, "JPEG")
#             print("Image has been converted and saved.")
#         except Exception as e:
#             return {"error": f"Failed to process image: {str(e)}"}
    
#     try:
#         if check_safe_text(transcribed_text) == "unsafe":
#             return "Sorry there is a potential security violation in your request. Please try a different prompt."
        
#         result = attempt_run_conversation(transcribed_text, image_path)
#         if check_safe_text(result) == "safe":
#             with open("chat_history.txt", "a") as chat_history:
#                 chat_history.write(f"User: {transcribed_text}\n")
#                 chat_history.write(f"Agent: {result}\n\n")
#             print("OUTPUT: " , result)
#             return {'answer': result}
#         else:
#             return "Sorry, I can't provide that information due to potential safety violation."
#     except Exception as e:
#         return {"error": f"Sorry, I am unable to answer that: {str(e)}"}
