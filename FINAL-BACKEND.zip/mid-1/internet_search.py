import requests
from bs4 import BeautifulSoup
import openai

# Set OpenAI API key
openai.api_key = ''

def fetch_full_page_content(url):
    """
    Fetches the full content of a webpage for analysis.
    """
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        return soup.get_text(separator="\n").strip()
    except requests.RequestException as e:
        return f"Failed to fetch the content: {e}"

def google_search(query):
    """
    Uses SerpAPI to get the first result link for a query.
    """
    serp_api_key = ''
    params = {
        "engine": "google",
        "q": query,
        "api_key": serp_api_key,
        "location": "United States",
        "hl": "en"
    }
    try:
        response = requests.get("https://serpapi.com/search", params=params)
        response.raise_for_status()
        results = response.json()
        if 'organic_results' in results and results['organic_results']:
            return results['organic_results'][0]['link']
        return "No search results found."
    except requests.RequestException as e:
        return f"Search error: {e}"

def openai_answer_from_search(search_text):
    """
    Uses OpenAI's GPT model to generate a response from the text.
    """
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Answer the user's query based on the following information."},
                {"role": "user", "content": search_text}
            ],
            max_tokens=800
        )
        return response['choices'][0]['message']['content']
    except openai.error.OpenAIError as e:
        return f"OpenAI API error: {e}"

def internet_search(query):
    """
    Main function to search the internet and generate an answer.
    """
    search_url = google_search(query)
    if search_url.startswith("Failed") or search_url.startswith("Error") or search_url == "No search results found":
        return search_url
    page_content = fetch_full_page_content(search_url)
    if page_content.startswith("Failed") or page_content.startswith("Error"):
        return page_content
    final_answer = openai_answer_from_search(page_content)
    return final_answer

