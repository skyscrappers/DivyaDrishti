import os

def general_chat(query):
    from together import Together

    chat_history_file = "chat_history.txt"
    
    if not os.path.exists(chat_history_file):
        with open(chat_history_file, "w") as file:
            file.write("")
    
    with open(chat_history_file, "r") as file:
        history_lines = file.readlines()
    
    last_50_messages = history_lines[-50:] if len(history_lines) > 50 else history_lines
    context = "".join(last_50_messages)
    
    client = Together(api_key="")
    
    response = client.chat.completions.create(
        model="meta-llama/Llama-3.2-11B-Vision-Instruct-Turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant which answers. Current context: {context}"},
            {"role": "user", "content": context + f"INPUT: {query}\n"}
        ],
        max_tokens=4000,
        temperature=0.06,
        top_p=0.7,
        top_k=50,
        repetition_penalty=1.0,
        stop=["<|eot_id|>", "<|eom_id|>"],
        stream=False
    )

    reply = response.choices[0].message.content.strip()
    
    with open(chat_history_file, "a") as file:
        file.write(f"(general_chat TOOL)\nINPUT: {query}\nOUTPUT: {reply}\n\n")
    
    return reply
