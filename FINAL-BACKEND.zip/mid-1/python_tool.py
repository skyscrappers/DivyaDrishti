def python_tool(query): 
    import os
    import openai
    from langchain.chat_models import ChatOpenAI
    from langchain.agents import Tool, initialize_agent
    from langchain_experimental.tools import PythonREPLTool

    openai_api_key = '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'
    os.environ["OPENAI_API_KEY"] = openai_api_key
    openai.api_key = openai_api_key

    llm = ChatOpenAI(model="gpt-4", temperature=0, openai_api_key=openai_api_key)

    python_tool = PythonREPLTool()

    tools = [python_tool]

    agent = initialize_agent(
        tools,
        llm,
        agent_type="zero-shot-react-description",
        verbose=True,
        handle_parsing_errors=True
    )

    return agent.run(query)
