def python_tool(query): 
    import os
    import openai
    from langchain.chat_models import ChatOpenAI
    from langchain.agents import Tool, initialize_agent
    from langchain_experimental.tools import PythonREPLTool

    openai_api_key = ''
    os.environ["OPENAI_API_KEY"] = openai_api_key
    openai.api_key = openai_api_key

    llm = ChatOpenAI(model="gpt-4", temperature=0, openai_api_key=openai_api_key)

    python_tool = PythonREPLTool()

    tools = [python_tool]

    agent = initialize_agent(
        tools,
        llm,
        agent_type="zero-shot-react-description",
        verbose=True,
        handle_parsing_errors=True
    )

    return agent.run(query)
