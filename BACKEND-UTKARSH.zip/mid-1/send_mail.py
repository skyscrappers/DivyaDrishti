import smtplib, os
from email.mime.text import MIMEText
from groq import Groq

def send_mail(user_prompt):

    os.environ["GROQ_API_KEY"] = "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"
    client = Groq(api_key=os.getenv('GROQ_API_KEY'))

    MODEL = "llama-3.1-8b-instant"

    messages = [
        {
            "role": "system",
            "content": "You are supposed to output NOTHING except what has been asked to. You are a tool which extracts the SUBJECT, BODY and RECEIVER address from the user template and return it as: '[SUBJECT , BODY , RECEIVER]', only write your output in the format specified and write nothing else at all and dont deviate at all and in a single line itself you can use backslash n for spaces if at all. dont use any comma except for seperation, make up a subject if can't decipher from user prompt but dont ever break the format: [SUBJECT , BODY , RECEIVER]"
        },
        {
            "role": "user",
            "content": user_prompt,
        }
    ]

    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        max_tokens=4096,
    )
    
    response_message_content = response.choices[0].message.content
    
    response_message_content = response_message_content[1:-1]


    subject, body, receiver = response_message_content.split(" , ")

    print(receiver)
    print(subject)
    print(body)


    sender = "utkarsh21570@iiitd.ac.in"
    password = "jcpk ewix oryf rzpe" 

    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = receiver

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()  
    server.login(sender, password)
    server.sendmail(sender, receiver, msg.as_string())
    server.quit()

    return "Email sent successfully"
