


def query_student_erp_portal(query):

    
    from sqlalchemy import create_engine
    from langchain_community.utilities import SQLDatabase
    from langchain_community.agent_toolkits import create_sql_agent
    from langchain.chat_models import ChatOpenAI
    from langchain.schema import OutputParserException

    API_KEY = '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'

    engine = create_engine('sqlite:///StudentPerformanceDB.sqlite')
    db = SQLDatabase(engine)

    llm = ChatOpenAI(api_key=API_KEY, model="gpt-4o-mini", temperature=0)

    def query_database(user_query, max_retries=3):
        agent_executor = create_sql_agent(llm=llm, db=db, verbose=True, handle_parsing_errors=True)
        retries = 0
        while retries < max_retries:
            try:
                result = agent_executor.invoke({"input": user_query})
                return result['output'] if 'output' in result else result
            except OutputParserException as e:
                retries += 1
        return "Failed to process the query after multiple attempts."
    
    reply = query_database(query)

    chat_history_file = "chat_history.txt"
    
    with open(chat_history_file, "a") as file:
        file.write(f"INPUT: {query}\nOUTPUT BY student_erp_portal TOOL: {reply}\n\n")
    
    return reply 


