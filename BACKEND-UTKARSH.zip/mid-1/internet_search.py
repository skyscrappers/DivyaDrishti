import requests
import os
from together import Together
from duckduckgo_search import DDGS
from bs4 import BeautifulSoup

together_api_key = '19ab173ba135c06aa5308a89adec95f54325f552b8ac9cd9b8ddcab0c4bed5c6'
os.environ["TOGETHER_API_KEY"] = together_api_key
client = Together(api_key=together_api_key)

def fetch_full_page_content(url):
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            return soup.get_text(separator="\n").strip()
        return f"Failed to fetch the content from {url}"
    except Exception as e:
        return f"Error fetching the content: {str(e)}"

def internet_search(query):
    ddgs = DDGS()
    results = ddgs.text(query, max_results=1)
    
    for result in results:
        if 'href' in result:  # Get the URL of the first result
            page_content = fetch_full_page_content(result['href'])
            return page_content
        elif 'body' in result:
            return result['body']
        elif 'title' in result:
            return result['title']
    
    return "Search failed"

def llama_answer_from_search(search_text):
    MODEL = "meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo"
    messages = [
        {
            "role": "system",
            "content": "Use the following information to answer the user's query based on relevant information."
        },
        {
            "role": "user",
            "content": search_text,
        }
    ]
    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        max_tokens=8000
    )
    return response.choices[0].message.content

def internet_search_and_llama_response(query):
    search_info = internet_search(query)
    
    if search_info.startswith("Failed") or search_info.startswith("Error"):
        return search_info
    final_answer = llama_answer_from_search(search_info)
    return final_answer

